from flask import Flask, jsonify, request
import pandas as pd
from demographic_filtering import output
from content_filtering import get_recommendations

articles_data = pd.read_csv('articles.csv')
all_articles = articles_data[['url', 'title', 'text', 'lang', 'total_events']]
liked_articles = []
not_liked_articles = []

app = Flask(__name__)

def assign_val():
    m_data = {
        "url": all_articles.iloc[0, 0],
        "title": all_articles.iloc[0, 1],
        "text": all_articles.iloc[0, 2] or "N/A",
        "lang": all_articles.iloc[0, 3],
        "total_events": all_articles.iloc[0, 4]
    }
    return m_data

@app.route("/get-article")
def get_article():
    article_info = assign_val()
    return jsonify({
        "data": article_info,
        "status": "success"
    })

@app.route("/liked-article")
def liked_article():
    global all_articles
    article_info = assign_val()
    liked_articles.append(article_info)
    all_articles.drop([0], inplace=True)
    all_articles = all_articles.reset_index(drop=True)
    return jsonify({
        "status": "success"
    })

@app.route("/unliked-article")
def unliked_article():
    global all_articles
    article_info = assign_val()
    not_liked_articles.append(article_info)
    all_articles.drop([0], inplace=True)
    all_articles = all_articles.reset_index(drop=True)
    return jsonify({
        "status": "success"
    })

@app.route("/popular-articles")
def popular_articles():
    popular_articles_data = all_articles.sort_values(by='total_events', ascending=False).head(20)
    popular_articles_list = popular_articles_data.to_dict(orient='records')
    return jsonify({
        "data": popular_articles_list,
        "status": "success"
    })

@app.route("/recommended-articles")
def recommended_articles():
    if not liked_articles:
        return jsonify({
            "data": [],
            "message": "No liked articles to recommend similar articles.",
            "status": "failure"
        })
    
    recommended_articles_list = []
    for article in liked_articles:
        recommendations = get_recommendations(article["title"])
        recommended_articles_list.extend(recommendations)

    recommended_articles_df = pd.DataFrame(recommended_articles_list).drop_duplicates().head(10)
    recommended_articles = recommended_articles_df.to_dict(orient='records')

    return jsonify({
        "data": recommended_articles,
        "status": "success"
    })

if __name__ == "__main__":
    app.run()
